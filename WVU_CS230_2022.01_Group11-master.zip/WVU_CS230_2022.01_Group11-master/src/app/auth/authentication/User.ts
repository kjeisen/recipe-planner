

export class User{
    displayName:any;
    photoUrl:any;
    userID:any;

    constructor(){ 
    }

}
