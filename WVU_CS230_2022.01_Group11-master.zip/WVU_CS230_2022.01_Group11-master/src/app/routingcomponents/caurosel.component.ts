import { Component } from "@angular/core";

@Component({
    selector: 'rp-caurosel',
    templateUrl: 'caurosel.component.html',
    styleUrls: ['caurosel.component.css']
})

export class Caurosel{

}