export const environment = {
  firebase: {
    projectId: 'reciplanner-394bb',
    appId: '1:1032468306005:web:4b27059f706d248e095cdc',
    databaseURL: 'https://reciplanner-394bb-default-rtdb.firebaseio.com',
    storageBucket: 'reciplanner-394bb.appspot.com',
    apiKey: 'AIzaSyCQLuQPY8mDfONPc3XAOvegzdvYP7Ks23M',
    authDomain: 'reciplanner-394bb.firebaseapp.com',
    messagingSenderId: '1032468306005',
  },
  production: true
};
